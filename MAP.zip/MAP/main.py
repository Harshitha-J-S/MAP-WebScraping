from scrappers.single_threaded import single_threaded_scraper
from scrappers.multi_threaded import multi_threaded_scraper
from utils.metrics import record_system_usage, display_results

def evaluate_scrapers(urls):
    results = {}
    cpu_usage = []
    mem_usage = []

    # Single-threaded
    print("Running Single-threaded Scraper...")
    cpu, mem = record_system_usage()
    pages, t = single_threaded_scraper(urls)
    results["Single Threaded"] = (pages, t)
    cpu_usage.append(cpu)
    mem_usage.append(mem)

    # Multi-threaded
    print("Running Multi-threaded Scraper...")
    cpu, mem = record_system_usage()
    pages, t = multi_threaded_scraper(urls)
    results["Multi Threaded"] = (pages, t)
    cpu_usage.append(cpu)
    mem_usage.append(mem)

    # Display and compare
    display_results(results, cpu_usage, mem_usage)

    # Compute Speedup
    base_time = results["Single Threaded"][1]
    print("\n⚡ Speedup Comparison:")
    for name, (_, t) in results.items():
        if name != "Single Threaded":
            print(f"{name}: {base_time / t:.2f}x faster")

if __name__ == "__main__":
    urls = [f"https://quotes.toscrape.com/page/{i}/" for i in range(1, 21)]
    evaluate_scrapers(urls)
