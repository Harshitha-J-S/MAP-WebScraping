import time
import psutil
import pandas as pd
from scrappers.single_threaded import single_threaded_scraper
from scrappers.multi_threaded import multi_threaded_scraper

# Different workload sizes for scalability test
URL_COUNTS = [10, 50, 100, 200]
BASE_URLS = [
    f"https://httpbin.org/delay/1" for _ in range(max(URL_COUNTS))
]

def measure(func, urls):
    start_cpu = psutil.cpu_percent(interval=None)
    start_time = time.time()
    func(urls)
    end_time = time.time()
    end_cpu = psutil.cpu_percent(interval=None)
    duration = end_time - start_time
    pages_per_min = (len(urls) / duration) * 60
    return duration, pages_per_min, (end_cpu - start_cpu)

results = []

for n in URL_COUNTS:
    urls = BASE_URLS[:n]
    print(f"\n=== Testing with {n} URLs ===")

    # Single-threaded
    t1, p1, c1 = measure(single_threaded_scraper, urls)
    # Multi-threaded
    t2, p2, c2 = measure(multi_threaded_scraper, urls)

    results.append({
        "URLs": n,
        "Single_Time": t1,
        "Multi_Time": t2,
        "Single_Pages/min": p1,
        "Multi_Pages/min": p2,
    })

# Save results
df = pd.DataFrame(results)
df.to_csv("scalability_results.csv", index=False)
print("\n✅ Scalability test completed! Results saved to scalability_results.csv")
print(df)
