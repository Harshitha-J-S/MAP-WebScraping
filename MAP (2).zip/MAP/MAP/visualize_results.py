import pandas as pd
import matplotlib.pyplot as plt

# Load scalability results
df = pd.read_csv("scalability_results.csv")

# Plot 1: Execution Time vs Number of URLs
plt.figure(figsize=(10, 6))
plt.plot(df["URLs"], df["Single_Time"], marker='o', label="Single-threaded")
plt.plot(df["URLs"], df["Multi_Time"], marker='o', label="Multi-threaded")
plt.title("Scalability Comparison: Execution Time vs. Number of URLs")
plt.xlabel("Number of URLs")
plt.ylabel("Execution Time (seconds)")
plt.legend()
plt.grid(True)
plt.show()

# Plot 2: Pages Scraped per Minute vs Number of URLs
plt.figure(figsize=(10, 6))
plt.plot(df["URLs"], df["Single_Pages/min"], marker='o', label="Single-threaded")
plt.plot(df["URLs"], df["Multi_Pages/min"], marker='o', label="Multi-threaded")
plt.title("Scalability Comparison: Pages Scraped per Minute")
plt.xlabel("Number of URLs")
plt.ylabel("Pages per Minute")
plt.legend()
plt.grid(True)
plt.show()
