import psutil
import matplotlib.pyplot as plt

def record_system_usage():
    cpu = psutil.cpu_percent()
    mem = psutil.virtual_memory().percent
    return cpu, mem

def display_results(results, cpu_usage, mem_usage):
    print("\n📊 Performance Summary:\n")
    print(f"{'Method':<20}{'Pages':<10}{'Time(s)':<10}{'Pages/min':<15}{'CPU%':<10}{'Mem%':<10}")
    print("-" * 70)
    
    for i, (name, (pages, t)) in enumerate(results.items()):
        pages_per_min = pages / (t / 60)
        print(f"{name:<20}{pages:<10}{t:<10.2f}{pages_per_min:<15.2f}{cpu_usage[i]:<10.2f}{mem_usage[i]:<10.2f}")

    # Bar chart for visualization
    plt.figure(figsize=(9, 5))
    plt.bar(results.keys(), [v[1] for v in results.values()], color=['red', 'blue', 'green'])
    plt.title("Execution Time Comparison")
    plt.ylabel("Time (seconds)")
    plt.show()
