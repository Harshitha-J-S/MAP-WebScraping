import time
import requests
from multiprocessing import Pool, cpu_count

def fetch_url(url):
    """Helper to fetch a single URL."""
    try:
        response = requests.get(url, timeout=5)
        if response.status_code == 200:
            return len(response.text)
        else:
            return None
    except Exception:
        return None

def multi_process_scraper(urls):
    """Scraper using multiprocessing for true parallelism."""
    start_time = time.time()
    num_processes = min(cpu_count(), len(urls))
    print(f"🔹 Using {num_processes} CPU cores for scraping...")

    with Pool(processes=num_processes) as pool:
        results = pool.map(fetch_url, urls)

    successful = [r for r in results if r is not None]
    duration = time.time() - start_time

    print(f"✅ Multi-processing: Scraped {len(successful)} / {len(urls)} pages in {duration:.2f}s")
    return len(successful), duration
