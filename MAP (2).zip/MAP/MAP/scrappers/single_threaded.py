
import requests
from bs4 import BeautifulSoup
import time

def single_threaded_scraper(urls):
    """Scrapes URLs one by one using requests (blocking)."""
    start = time.time()
    pages_scraped = 0

    for url in urls:
        try:
            r = requests.get(url)
            if r.status_code == 200:
                soup = BeautifulSoup(r.text, 'html.parser')
                pages_scraped += 1
        except Exception as e:
            print("Error:", e)

    end = time.time()
    return pages_scraped, end - start
