import threading
import requests
from bs4 import BeautifulSoup
import time

def multi_threaded_scraper(urls):
    """Scrapes URLs concurrently using threading."""
    start = time.time()
    pages_scraped = 0
    lock = threading.Lock()

    def fetch(url):
        nonlocal pages_scraped
        try:
            r = requests.get(url)
            if r.status_code == 200:
                soup = BeautifulSoup(r.text, 'html.parser')
                with lock:
                    pages_scraped += 1
        except:
            pass

    threads = []
    for url in urls:
        t = threading.Thread(target=fetch, args=(url,))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    end = time.time()
    return pages_scraped, end - start
